"""Super useful module"""

def print_num(number):
    print(number)
